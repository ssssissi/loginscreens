import 'package:local_auth/local_auth.dart';
import 'package:flutter/services.dart';

class MyAuth {
  static final _auth = LocalAuthentication();
  static Future<bool> hasBiometrics() async{
    try{
      return await _auth.canCheckBiometrics;
    } on PlatformException catch (e){
      return false;
    }
  }
  static Future<List<BiometricType>> getBiometrics() async{
    try{
      return await _auth.getAvailableBiometrics();
    } on PlatformException catch (e) {
      return <BiometricType>[];
    }
  }
  static Future<bool> authenticate() async {
    final isAvailable=await hasBiometrics();
    if (!isAvailable) return false;
    try {
      return await _auth.authenticateWithBiometrics(localizedReason: "Scan Fingerprint to proceed",
        useErrorDialogs: true,
        stickyAuth: true,);
    }on PlatformException catch (e){
      return false;
    }
  }
}
